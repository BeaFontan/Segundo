<?php

for ($k=0; $k<2; $k++) 
    mostra10numeros();


function mostra10numeros()
{
    for ($i=0; $i<10; $i++)
    {
        echo "o numero ".$i."<br>";
    }
}


echo "despois do bucle!";

?>