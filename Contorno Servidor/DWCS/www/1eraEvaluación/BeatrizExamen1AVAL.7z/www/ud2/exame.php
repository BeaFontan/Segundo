﻿<html>
<head><title>Curtocircuito 2021</title>
<link type="text/css" rel="stylesheet" href="exame.css"> 
</head>
<body>

<div id="contenedor">

<header>
<h2>Curtocircuito 2021 </h2>
</header>
<aside id="esquerda"></aside>
<aside id="dereita"></aside>
<article id="noiteCurta"></article>

<aside id="formulario">
	<form name="form1" method="GET" action="exame.php">
			<p>Buscar curta:</p>
		
			
			   <input type="text" name="palabra" size="10" maxlength="50" value="" style="width:230px"> 
			   <input type="submit" name="buscar" value="Buscar" class="busca"> <br>
			<hr>
			   <input type="submit" name="listado" value="Ver listado completo das curtas"><br>
			  <p>Ordenado: </p>
			  	  <input type="submit" name="listaPolotitulo" value="Polo título"><br>
			      <input type="submit" name="listaPoloPais" value="Decrecente polo país"><br>
			  <p>Cambios: </p>
				<input type="submit" name="cambioPortugal" value="Cambio 'Portugal' por 'Galicia'"><br>
                <input type="submit" name="franciaPrimeira" value="Francia de primeira"><br>
		</form>
	

</aside>
<article id="taboa">
<?php
	require("datosCurtocircuito.php");

	if(isset($_GET["buscar"])){
		$palabraABuscar = strtolower($_GET["palabra"]);
		$arrayEncontrado = [];

		foreach ($curtas as $titulo => $datos) {
			$noticiaMinus = strtolower($datos[0]);
			$paisMinus = strtolower($datos[2]);

			if (str_contains($noticiaMinus, $palabraABuscar) || str_contains($paisMinus, $palabraABuscar)) {
				$arrayEncontrado[$titulo] = $datos;
			}
		}

		$arrayCircuitos = $arrayEncontrado;
	}

	if (isset($_GET["listado"])) {
		$arrayCircuitos = $curtas;
	}

	if (isset($_GET["listaPolotitulo"])) {
		uksort($curtas, function ($a,$b){
			return strcasecmp($a, $b);
		});

		$arrayCircuitos = $curtas;
	}

	if (isset($_GET["listaPoloPais"])) {
		uksort($curtas, function ($a,$b){
			return strcasecmp($b[2], $a[2]);
		});

		$arrayCircuitos = $curtas;
	}

	if (isset($_GET["cambioPortugal"])) {
		foreach ($curtas as $titulo => $datos) {
			$titulo = str_replace("Portugal", "Galicia", $titulo);
			$datos[0] = str_replace("Portugal", "Galicia", $datos[0]);
			$datos[2] = str_replace("Portugal", "Galicia", $datos[2]);

			$arrayMod[$titulo] = $datos;
		}

		$arrayCircuitos = $arrayMod;
	}

	if (isset($_GET["franciaPrimeira"])) {
		foreach ($curtas as $titulo => $datos) {
			if (str_contains($datos[2], "Francia") || str_contains($datos[2], "Francia,") ) {
				$datos[2] = str_replace("Francia,", "", $datos[2]);
				$datos[2] = str_replace("Francia", "", $datos[2]);
				$datos[2] = "Francia," . $datos[2];
			}

			$arrayMod[$titulo] = $datos;
		}

		$arrayCircuitos = $arrayMod;
	}
	?>  

	<table>
		<tr>
			<th>titulo</th>
			<th>Piloto</th>
			<th>Posicion</th>
			<th>Paises</th>
		</tr>
		<?php

			if (empty($arrayCircuitos)) {
				echo "<p> Non se atopan resultados</p>";
			}else {
				foreach ($arrayCircuitos as $titulo => $datos) {
					echo "<tr>
							<td>{$titulo}</td>
							<td>{$datos[0]}</td>
							<td>{$datos[1]}</td>
							<td>{$datos[2]}</td>
						</tr>";
				}
			}

		?>
	</table>


</article>
</div>
</body>
</html>
