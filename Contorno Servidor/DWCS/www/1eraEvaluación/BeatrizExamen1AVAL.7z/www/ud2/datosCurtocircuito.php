﻿<?php

$curtas=array("Como Fernando Pessoa Salvou Portugal"=>array("Eugène Green","26","Portugal, Francia, Bélxica"),
				"Levittown"=>array("Nelson Bourrec Carter","13","Francia, EUA"),
				"A muller do saco"=>array("Erica Scoggins","17","EUA"),
				"Terra bendita"=>array("Pham Ngoc Lan","18","Vietnam "),
				"27 pensamentos sobre o meu pai"=>array("Mike Hoolboom","25","Canadá"),
				"Marea"=>array("Manon Coubia","32","Bélxica, Francia"),
				"+ 6 Gain"=>array("Jorn Plucieniczak","26","Bélxica"),
				"Operación Jane Walk"=>array("Leonhard Müllner, Robin Klengel","16","Austria"),
				"RISE"=>array("Bárbara Wagner, Benjamin de Burca","20","Brasil, Canadá, EUA"));

?>