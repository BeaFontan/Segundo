<?php

include 'config.php';

function listarTodos($pdo){
    try {
        $query = $pdo->query("Select * from naves");
        $query->execute();
        return $query->fetchAll();
       
    } catch (PDOException $e) {
        echo "Erro en listar Todas " . $e->getMessage();
    }
}

function insertar($pdo, $nome, $prezo){
    try {
        $alugado = "non";
        $imaxe = $nome.'.jpg';

        $query = $pdo->prepare("INSERT INTO `naves`(`nome`, `prezo`, `alugado`, `nomeImaxe`) VALUES (?,?,?,?)");
        $query->execute(array($nome, $prezo, $alugado, $imaxe));
        echo "<p>Nave insertada correctamente</p>";
        
       
    } catch (PDOException $e) {
        echo "Erro en insertar " . $e->getMessage();
    }
}

function alugar($pdo, $nomeNaveAAlugar){
    try {
        $valorSI = 'si';
        $query = $pdo->prepare("UPDATE `naves` SET `alugado`= ? WHERE nome like ?");
        $query->execute(array($valorSI,$nomeNaveAAlugar));
        echo "<p>Nave alugada correctamente</p>";
       
    } catch (PDOException $e) {
        echo "Erro en alugar " . $e->getMessage();
    }
}


function actualizarPrezo($pdo, $prezoNovo, $naveCambiarPrezo){
    try {
       $query = $pdo->prepare("UPDATE `naves` SET `prezo`= ? WHERE nome like ?");
       $query->execute(array($prezoNovo, $naveCambiarPrezo));
       echo "<p>Prezo actualizado correctamente</p>";
       
    } catch (PDOException $e) {
        echo "Erro en actualizar prezo " . $e->getMessage();
    }
}

function eliminar($pdo, $naveEliminar){
    try {
        $query = $pdo->prepare("DELETE FROM `naves` WHERE nome like ?");
        $query->execute(array($naveEliminar));
        echo "<p>Nave eliminada correctamente.</p>";
        
     } catch (PDOException $e) {
         echo "Erro eliminando " . $e->getMessage();
     }
}

if (isset($_GET["boton"])) {
    switch ($_GET["boton"]) {
        case 'listarTodos':
            $arrayNaves = listarTodos($pdo);
            break;

        case 'insertar':
            $nome = $_GET["textNome"];
            $prezo = $_GET["textPrezo"];

            if (!is_numeric($prezo)) {
                echo "<p> O prezo non é valido</p>";
                break;
            } elseif ($nome == "") {
                echo "<p> O nome non pode estar vacio</p>";
                break;
            }

            $prezo = (int) $prezo;
            insertar($pdo, $nome, $prezo);
            $arrayNaves = listarTodos($pdo);
            break;

        case 'alugar':
            $nomeNaveAAlugar = $_GET["selectAlugar"];
            alugar($pdo, $nomeNaveAAlugar);
            $arrayNaves = listarTodos($pdo);
            break;

        case 'actualizarPrezo':
            $prezoNovo = $_GET["textPrezoCambiar"];
            $naveCambiarPrezo = $_GET["selectActualizarPrezo"];

            if (!is_numeric($prezoNovo)) {
                echo "<p> O prezo non é valido</p>";
                break;
            }
            
            actualizarPrezo($pdo, $prezoNovo, $naveCambiarPrezo);
            $arrayNaves = listarTodos($pdo);
            break;

        case 'eliminar':
            $naveEliminar = $_GET["selectEliminar"];
            eliminar($pdo, $naveEliminar);
            $arrayNaves = listarTodos($pdo);
            break;
    }
}




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="aluguer.php" method="GET"> 
        <button type="submit">Volver</button>
    </form>
    
    <div>
        <?php
            if (empty($arrayNaves)) {
                echo "Non se encontran resultado";
            } else{
                foreach ($arrayNaves as $nave) {
                    $imaxe = "imaxes/" . $nave["nomeImaxe"];
                    echo '<div>
                                <div>'.$nave["nome"].'</div>
                                <div>'.$nave["prezo"].'</div>
                                <div>'.$nave["alugado"].'</div>
                                <img src="'.$imaxe.'" alt="imaxeNave">
                          </div>';
                }
            }
        ?>
    </div>
</body>
</html>