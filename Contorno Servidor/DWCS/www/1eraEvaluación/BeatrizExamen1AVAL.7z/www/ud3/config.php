<?php

$servidor = "dbmysql";
$usuario = "root";
$pass="root";
$bbdd="maqueta";

try {
    $pdo = new PDO("mysql:host={$servidor};dbname={$bbdd};charset=utf8", "$usuario", $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Conexión realizada correctamente";
} catch (PDOException $e) {
    echo "Erro na conexión " . $e->getMessage();
}

?>