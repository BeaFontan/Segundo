<?php
include 'config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="mostra.php", method="GET">
        <button type="submit" name="boton" value="listarTodos">Listar todas as naves</button></br></br></br>

        <hr>

        <p>Cubre os campos para insertar unha nave e logo pulsa INSERTAR:</p>

        <input type="text" name="textNome" placeholder="Nome">
        <input type="text" name="textPrezo" placeholder="Prezo">
        <button type="submit" name="boton" value="insertar">INSERTAR</button></br></br></br>

        <hr>
        <p>ALUGAR:</p>

        <select name="selectAlugar">
            <?php
                try {
                    $query = $pdo->query("Select Nome from naves where alugado like 'non'");
                    $query->execute();
                    $arrayNonAlugadas = $query->fetchAll();

                } catch (PDOException $e) {
                    echo "Erro en desplegar naves " . $e->getMessage();
                }

                foreach ($arrayNonAlugadas as $nave) {
                    echo '<option value="'.$nave["Nome"].'">'.$nave["Nome"].'</option>';
                }

                ?>
        </select>
        <button type="submit" name="boton" value="alugar">ALUGAR</button></br></br></br>
        
        <hr>

        <p>MODIFICAR PREZO: Selecciona a nave a modificar o prezo e introduce o novo prezo no campo</p>
        <select name="selectActualizarPrezo">
            <?php
                try {
                    $query = $pdo->query("Select Nome from naves");
                    $query->execute();
                    $arrayNonAlugadas = $query->fetchAll();

                } catch (PDOException $e) {
                    echo "Erro en desplegar naves " . $e->getMessage();
                }

                foreach ($arrayNonAlugadas as $nave) {
                    echo '<option value="'.$nave["Nome"].'">'.$nave["Nome"].'</option>';
                }

                ?>
        </select>
        <input type="text" name="textPrezoCambiar" placeholder="Novo prezo">
        <button type="submit" name="boton" value="actualizarPrezo">ACTUALIZAR PREZO</button></br></br></br>


        <hr>
        
        <p>ELIMINAR NAVE NON ALUGADA: Selecciona a nave sin alugar no desplegable y logo pulsa ELIMINAR</p>

        <select name="selectEliminar">
            <?php
                try {
                    $query = $pdo->query("Select Nome from naves where alugado like 'non'");
                    $query->execute();
                    $arrayNonAlugadas = $query->fetchAll();

                } catch (PDOException $e) {
                    echo "Erro en listar naves non alugadas para eliminar " . $e->getMessage();
                }

                foreach ($arrayNonAlugadas as $nave) {
                    echo '<option value="'.$nave["Nome"].'">'.$nave["Nome"].'</option>';
                }
                ?>
        </select>
        <button type="submit" name="boton" value="eliminar">ELIMINAR</button></br></br></br>
    </form>
</body>
</html>

