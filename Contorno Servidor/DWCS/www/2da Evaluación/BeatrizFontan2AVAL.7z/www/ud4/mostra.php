<?php
session_start();
require_once("Conexion.php");

$pdo = new Conexion();

if (!isset($_COOKIE["idioma_usuario"])) {
    $mensaxe = "Debes seleccionar o idioma";
    header("Location:login.php?mensaxe=$mensaxe");
    exit;
}


function mostrarComentario($pdo): mixed
{
    try {
        $query = $pdo->query("Select * from comentarios");
        $query->execute();
        return $query->fetchAll();
    } catch (PDOException $e) {
        return "Erro mostrando comentarios" . $e->getMessage();
    }  
}

function insertarComentario($pdo, $usuario, $comentario): string
{
    try {
        $query = $pdo->prepare("INSERT INTO `comentarios`(`usuario`, `comentario`)
             VALUES (?,?)");
        $query->execute([$usuario, $comentario]);
        return "Comentario añadido";
    } catch (PDOException $e) {
        return "Erro añadindo comentarios" . $e->getMessage();
    }  
}


$arrayComentarios = mostrarComentario($pdo);

if (isset($_POST["btnComnentar"])) {
    $comentario = htmlspecialchars($_POST["txtComentario"]);

    $mensaxe = insertarComentario($pdo, $_SESSION["datos"]["usuario"], $comentario);

    $arrayComentarios = mostrarComentario($pdo);
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="pecharSesion.php" method="post">
        <button type="submit">Pechar sesion</button>
    </form>

    <?php
    if (!empty($arrayComentarios)) {
        foreach ($arrayComentarios as $comentario) {
            echo'
                <h3>Comentario:</h5>
                <div>'.$comentario["usuario"].'</div><br>
                <div>'.$comentario["comentario"].'</div>
                ';
        }
    }
    ?>


    <form action="mostra.php" method="post">
        <br><br>
        <h3>Comentar:</h3>
        <input type="text" name="txtComentario" placeholder="Comentario"><br>
        <button type="submit" name="btnComnentar">Comentar</button>
    </form>

    <?php
        if (isset($mensaxe)) {
            echo "<p>".$mensaxe."<p>";
        }
    ?>
</body>
</html>

