<?php
if (isset($_GET["elixeLingua"])) {
    $idioma = $_GET["idioma"];

    setcookie("idioma_usuario", $idioma, time() + 100000);

    header("Location:login.php");
    exit;
}
?>
<!doctype html>
<head>
    <style type='text/css'>
        label
        {
                 display:inline-block;
                 width:8em;
        }
    </style>
</head>
<body>

<form action='login.php' method='GET'>
    <label>Selecciona</label>
    <select name='idioma'>
        <option value='galego'>Galego</option>
        <option value='ingles'>Inglés</option>
    </select>
    <input type='submit' name='elixeLingua' value='Enviar lingua'>
</form>

<h3>Credenciais</h3>
<form action='validalogin.php' method='post'>
    <label>Usuario</label><input type='text' name='usuario'><br>
    <label>Contrasinal</label><input type='text' name='contrasinal'> 
    <button type="submit" name="btnLogin">Login</button>
</form>

<?php
if (isset($_GET["mensaxe"])) {
    echo "<p>".$_GET["mensaxe"]."<p>";
}
?>
</body>
</html>