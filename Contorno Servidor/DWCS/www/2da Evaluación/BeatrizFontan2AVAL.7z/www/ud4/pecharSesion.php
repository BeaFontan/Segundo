<?php
session_start();
$_SESSION = [];
$_COOKIE = "";
session_destroy();

header("Location:login.php");
exit;