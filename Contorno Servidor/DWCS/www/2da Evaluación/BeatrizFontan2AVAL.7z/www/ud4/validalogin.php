<?php
session_start();

require_once "Conexion.php";

$pdo = new Conexion();

function login($pdo, $user): mixed
{
    try {
        $query = $pdo->prepare("SELECT * FROM `usuarios` WHERE usuario like ?");
        $query->execute([$user]);
        $usuario = $query->fetch();
        return $usuario ?: "Non existe o usuario";

    } catch (PDOException $e) {
        return "Erro no login" . $e->getMessage();
    }
}


if (isset($_POST["btnLogin"])) {
    $user = htmlspecialchars($_POST["usuario"]);
    $pass = htmlspecialchars($_POST["contrasinal"]);

    $usuario = login($pdo, $user);
   
    if (is_string($usuario)) {
        header("Location:login.php?mensaxe=$usuario");
        exit;

    } else {
        $passCorrecto = password_verify($pass, $usuario["contrasinal"]);

        if (!$passCorrecto) {
            $mensaxe = "Contrasinal incorrecto";
            header("Location:login.php?mensaxe=$mensaxe");
            exit;

        } else {
            session_regenerate_id(true);

            $datos = [
                "usuario" => $usuario["usuario"],
            ];

            $_SESSION["datos"] = $datos;

            header("Location:mostra.php");
            exit;
        }
    }

}