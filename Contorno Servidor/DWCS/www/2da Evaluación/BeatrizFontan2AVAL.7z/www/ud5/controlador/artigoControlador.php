<?php
declare(strict_types= 1);

require_once "../modelo/ArtigoModelo.php";
require_once "../vista/vistaArtigos.php";


formularioVista();

if (isset($_POST["mostrarTodos"])) {

    $arrayArtigos = ArtigoModelo::seleccionaTodos();

    mostrar($arrayArtigos);
}

if (isset($_POST["btnMostrarARtigo"])) {
    $nomeArtigo = "%".strtolower(htmlspecialchars($_POST["txtNomeArtigo"]))."%";

    $artigo = new ArtigoModelo($nomeArtigo, 0, '');

    $arrayArtigos = $artigo->seleccionaporNome();

    if (empty($arrayArtigos)) {
        echo "Non existe ese producto";
        
    } else {
        mostrar($arrayArtigos);
    }


}