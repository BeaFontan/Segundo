<?php declare(strict_types= 1);?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        table, th, td{
            border: 1px solid black;
            border-collapse: collapse;
        }

        img{
            width: 100px;
            height: 100px;
        }
    </style>
</head>
<body>
    <?php

    function formularioVista(): void
    {
        echo opcions();
    }
    
    function opcions(): void
    {
        echo '
        <form action="artigoControlador.php" method="post">
            <button type="submit" name="mostrarTodos">Mostrar Todos</button><br><br>
        </form>

        <form action="artigoControlador.php" method="post">
            <input type="text" name="txtNomeArtigo" placeholder="Introduce o artigo a ver"><br>
            <button type="submit" name="btnMostrarARtigo">Mostrar o artigo</button><br><br>
        </form>
        ';
    }

    function mostrar(array $arrayArtigos): void
    {
       foreach ($arrayArtigos as $artigo) {
        $imaxe = "imaxes/" . $artigo["imaxe"];

        echo '<table>
            <tr>
                <th>Nome</th>
                <th>prezo</th>
                <th>Imaxe</th>
            </tr>
            <tr>
                <td>'.$artigo["nomeArtigo"].'</td>
                <td>'.$artigo["prezo"].'</td>
                <td><img src="'.$imaxe.'" alt=""></td>
            </tr>

        </table>';
        }
    }

    ?>




</body>
</html>