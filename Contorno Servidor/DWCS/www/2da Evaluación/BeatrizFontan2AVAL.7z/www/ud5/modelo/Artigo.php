<?php
declare(strict_types= 1);

class Artigo
{
    protected string $nomeArtigo;
    protected float $prezo;
    protected string $imaxe;

    public function __construct(string $nomeArtigo, float $prezo, string $imaxe)
    {
        $this->nomeArtigo = $nomeArtigo;
        $this->prezo = $prezo;
        $this->imaxe = $imaxe;
    }
}