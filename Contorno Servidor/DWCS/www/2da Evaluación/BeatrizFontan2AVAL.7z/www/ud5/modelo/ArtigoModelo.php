<?php
declare(strict_types= 1);

require_once "Artigo.php";
require_once "Conexion.php";

class ArtigoModelo extends Artigo
{

    public function __construct(string $nomeArtigo, float $prezo, string $imaxe)
    {
        parent::__construct($nomeArtigo, $prezo, $imaxe);
    }

    //mostrar un artigo
    public function seleccionaporNome(): array
    {
        $pdo = new Conexion();

        try {
            $query = $pdo->prepare("SELECT * FROM `artigos` where nomeArtigo like LOWER(?)");
            $query->execute([$this->nomeArtigo]);
            return $query->fetchAll(PDO::FETCH_ASSOC);

        } catch (PDOException $e) {
            die("Erro mostrando por nome" . $e->getMessage());
        }
    }

    //Mostrar todos
    public static function seleccionaTodos(): array
    {
        $pdo = new Conexion();

        try {
            $query = $pdo->prepare("SELECT * FROM `artigos`");
            $query->execute();
            return $query->fetchAll(PDO::FETCH_ASSOC);

        } catch (PDOException $e) {
            die("Erro mostrando todos" . $e->getMessage());
        }
    }

}