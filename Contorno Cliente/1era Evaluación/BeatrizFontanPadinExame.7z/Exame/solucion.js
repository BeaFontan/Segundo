/****************

Nombre y apellidos: Beatriz Fontán Padín
Fecha: 13/12/2024


Recorda engadir os comentarios que fagan falta!!!
******************/

const dataLoader = document.getElementById("dataLoader");
const dataLoader2 = document.getElementById("dataLoader2");
const dataPusher = document.getElementById("dataPusher");

// ***************************************** Editar a partir de aquí ******************************************/

//Ejercicio 1

function calcularFactorial(valor) {

	let resultado = 1; //Inicializamos valor a 1 para que no nos de problemas a la hora de multiplicar por 0

	try {
		//Comprobar si es no es un numero
		if (isNaN(valor)) {
			throw new Error("-1");
			
		} else if (valor <0) {//Comprobar que el valor sea mayor a 
			throw new RangeError("-1");
		}
		
		//Bucle para recorrer el rango de número y almacenar el resultado de la multiplicaicón
		for (let i = 1; i <= valor; i++) {
			 resultado *= i;
		}	

	} catch (error) {
		return -1;//Respuesta de error
	}

	return resultado;//Imprimir resultado
}



//Ejercicio 2

function avaliarNota(nota) {

	let categoria; // Declaración de variable que almacenará el texto correspondiente a la nota
	let respuesta;

	// Asignar la categoría dependiendo de la nota para luego poder procesar en switch
	if (nota >= 9 && nota <= 10) {
		categoria = "Sobresaliente";
	} else if (nota >= 7 && nota < 9) {
		categoria = "Notable";
	} else if (nota >= 6 && nota < 7) {
		categoria = "Bien";
	} else if (nota >= 5 && nota < 6) {
		categoria = "Suficiente";
	} else if (nota >= 0 && nota < 5) {
		categoria = "Insuficiente";
	} else {
		categoria = "Invalida";
	}

	// Usar el switch para mostrar la calificación según la nota procesada
	switch (categoria) {
		case "Sobresaliente":
			respuesta = "Sobresaliente";
			break;
		case "Notable":
			respuesta = "Notable";
			break;
		case "Bien":
			respuesta = "Bien";
			break;
		case "Suficiente":
			respuesta = "Suficiente";
			break;
		case "Insuficiente":
			respuesta = "Insuficiente";
			break;
		default:
			respuesta = "Nota no válida. Rango de 0 a 10";
			break;
	}

	//Imprimimos resultado
	return respuesta;

}


//Ejercicio 3
function sumaPares(num1, num2) {

	//Casteos de los valores a números 
	num1 = parseInt(num1);
	num2 = parseInt(num2);

	let resultado = 0;

	try {

		//Comprobmos si los números introducidos son válidos
		if (isNaN(num1) || isNaN(num2)) {
			throw new Error();//Sino lanzamos un error
		}

		//Bucle para recorrer el rango de números 
		for (let i = num1; i <= num2; i++) {
			if (i % 2 == 0) {//si el número el módulo de i es igual a cero, es decir, es par
				resultado + i;//Almacena número en el resultado.
			}
		}

	} catch (error) {
		return -1;
	}

	return resultado;//Devolver el resultado.
}


//Ejercicio 4
function likes(totalLikes) {

    let resultado;
    
	//Comprobamos con un if en que rango de número se encuentra introducido para comprobar si son millones o miles
    if (totalLikes >= 1000000) {
        resultado = Math.floor(totalLikes / 1000000) + "M";
      } else if (totalLikes >= 1000) {
        resultado = Math.floor(totalLikes / 1000) + "K";
      } else {
        resultado = totalLikes.toString() + ", no se puede tranformar ni en k ni en M"; // Devolver el número como string
      }

	//Imprimimos resultado
   return resultado;
}
 

//Ejercicio 5: en mago.html.


function comprobarExercicios() {
	//Podes usar este código como exemplo para comprobar que as funcións actuan correctamente.
	dataPusher.innerHTML = " Valores entregados: Primer valor (" + dataLoader.value + ") <-> Segundo valor(" + dataLoader2.value + ")";
	
	dataPusher.innerHTML += "<br/>calcularFactorial("+dataLoader.value+") = " + calcularFactorial(dataLoader.value);
	dataPusher.innerHTML += "<br/>avaliarNota("+dataLoader.value+") = " + avaliarNota(dataLoader.value);
	dataPusher.innerHTML += "<br/>sumaPares("+dataLoader.value + ","+ dataLoader2.value+") = " + sumaPares(dataLoader.value, dataLoader2.value);
	dataPusher.innerHTML += "<br/>likes("+dataLoader.value+") = " + likes(dataLoader.value);
	
}
